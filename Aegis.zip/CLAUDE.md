# Aegis - Working Context (Updated)

This file tracks the current practical state of the project. If this file conflicts with `ARCHITECTURE_LOCK.md` or `PROJECT_CONTEXT_HANDOFF.md`, those two files win.

## Source of Truth Order

1. `ARCHITECTURE_LOCK.md`
2. `PROJECT_CONTEXT_HANDOFF.md`
3. `Claude.md`
4. Prompt XML files only where non-conflicting

## Project Identity

- Project: Aegis Smart Home AI Assistant
- Purpose: internship prototype
- Language: Python 3.10+
- Runtime direction: cloud LLM formatting via LiteLLM, local retrieval and parsing

## Locked Stack

- Python 3.10+
- Gemini 2.5 Flash
- LiteLLM pinned to `1.82.6`
- ChromaDB local
- sentence-transformers with `all-MiniLM-L6-v2`
- FastAPI + httpx
- pdfplumber + PyMuPDF

## LiteLLM Security Policy

- Allowed: `litellm==1.82.6`
- Blocked: `1.82.7`, `1.82.8`
- No floating or open-ended version ranges for LiteLLM in this phase

## Current Project Structure (V1)

```
src/aegis/
├── core/
│   ├── config.py                    # AegisConfig
│   └── orchestrator.py              # keyword routing + CLI
├── billing/
│   ├── types.py                     # CanonicalBill + schemas
│   ├── config.py                    # BillingConfig
│   ├── answerer.py                  # answer_billing_question
│   ├── query_classifier.py          # query intent routing
│   ├── llm_formatter.py             # grounded answer formatting
│   ├── cli.py                       # billing CLI (inspect/ingest/query)
│   ├── parser/
│   │   ├── extractors.py            # PDF text/table extraction
│   │   ├── normalize.py             # field normalization
│   │   ├── pvvnl_parser.py          # PVVNL bill parser
│   │   └── msedcl_parser.py         # MSEDCL bill parser
│   └── rag/
│       ├── embeddings.py            # sentence-transformers wrapper
│       ├── retriever.py             # Chroma retrieval + metadata filtering
│       └── store.py                 # canonical JSON + ChromaDB persistence
├── weather/
│   ├── fetcher.py                   # OpenWeatherMap + mock fallback
│   └── advisor.py                   # LiteLLM → Gemini 2.5 Flash advice
├── ac_control/
│   ├── server.py                    # FastAPI mock hardware (port 8765)
│   ├── classifier.py                # LiteLLM intent + keyword fallback
│   └── client.py                    # httpx client → ACActionResult
└── ui/
    └── streamlit_app.py             # 3-tab prototype UI
```

## Current Implementation Status (88 tests passing)

**Billing RAG — `src/aegis/billing/`**
- Canonical bill parse pipeline from PDF extraction
- Chunked Chroma upsert for three collections: `bill_fields`, `bill_charges`, `bill_history`
- Query classification across exact/charge/history/fallback/insufficient
- Grounded answer formatting: LiteLLM for charge/history, deterministic for exact fields
- `litellm_enabled=True` by default; deterministic fallback as silent safety net

**Weather Advisor — `src/aegis/weather/`**
- `fetch_weather(city, config)` — OpenWeatherMap live API + mock fallback
- `advise_weather(weather, question, config)` — LiteLLM → Gemini 2.5 Flash with deterministic fallback

**AC Control — `src/aegis/ac_control/`**
- FastAPI mock hardware server: `POST /ac/on`, `POST /ac/off`, `GET /ac/status` (port 8765)
- `classify_ac_intent(text, config)` — LiteLLM JSON intent + keyword fallback
- `execute_ac_command(intent, config)` → `ACActionResult`

**Orchestrator — `src/aegis/core/orchestrator.py`**
- Keyword routing to weather / AC / billing
- LiteLLM fallback for ambiguous queries
- CLI: `uv run aegis ask "<question>"`

**Streamlit UI — `src/aegis/ui/streamlit_app.py`**
- Three tabs: Billing / Weather Advisor / AC Control
- Loads `.env` via `load_dotenv()` at startup
- **Prototype/testing surface only — not the production frontend**

## Operational Paths

```bash
uv run aegis ask "<question>"                      # orchestrator CLI
uv run aegis-billing query --question "..." --pdf   # billing CLI
uv run aegis-ac-server                              # mock hardware on port 8765
uv run aegis-ui                                     # Streamlit prototype UI
uv run pytest tests/ -v                             # 88 tests passing
```

## Non-Negotiable Rules

- LLM never directly calls external APIs, FastAPI endpoints, or ChromaDB
- Python controls all I/O and retrieval decisions
- Billing answers must be grounded strictly in parsed/retrieved bill context
- `current_payable`, `total_payable_rounded`, and `payable_by_due_date` are distinct and must never be merged
- Weather, AC, Billing stay fully independent — no cross-feature coupling

## Billing Query Contract (Locked)

- Single-bill mode only
- `query` requires explicit `--pdf`
- `answer_billing_question()` requires explicit `pdf_path`
- If context is missing or not found in bill evidence, answer must say so clearly
- Vector retrieval never overrides valid exact structured values

## Billing Data Flow

1. Read PDF (`pdfplumber` + `PyMuPDF`)
2. Parse to canonical schema (`CanonicalBill`)
3. Persist canonical JSON in `data/processed/`
4. Upsert vectors into Chroma in `data/vector_store/`
5. Classify query intent
6. Resolve exact schema fields first
7. Use metadata-filtered semantic fallback only when needed
8. Format grounded answer (deterministic for exact fields, LiteLLM for charge/history)

## Remaining Production Items (require explicit user approval)

1. **LiteLLM mandatory** — `litellm_enabled=True` by default; startup fails if key missing
2. **Proper frontend** — after Streamlit validation; talks to FastAPI only

## Notes for Future Sessions

- Do not reopen architecture choices unless explicitly requested
- Do not implement remaining production items without explicit user approval
- Prefer updating `ARCHITECTURE_LOCK.md` and `PROJECT_CONTEXT_HANDOFF.md` first, then mirror concise changes here
- Keep this file practical and implementation-aligned, not speculative
