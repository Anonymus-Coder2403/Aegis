# Aegis Architecture Lock

## Status

This file is the authoritative lock for Aegis architecture and stack decisions.
Where this file conflicts with `Prompt.xml`, `Task.xml`, or `aegis_codex_agent_prompt.xml`, this file wins.

`Claude.md` was previously the working source of truth. This file and `PROJECT_CONTEXT_HANDOFF.md` now supersede conflicting statements in `Prompt.xml`, `Task.xml`, and `aegis_codex_agent_prompt.xml`. The XML files remain historical context only where they align with the locked markdown documents.

## Project Goal

Aegis is a production-style internship prototype for a smart home AI assistant that must handle weather advice, AC control through mocked hardware, and electricity-bill question answering with strict grounding over local bill documents.

## Locked Stack

- Python 3.10+
- Gemini 2.5 Flash
- LiteLLM `1.82.6` (security-pinned)
- ChromaDB local
- `sentence-transformers` with `all-MiniLM-L6-v2`
- FastAPI + httpx
- pdfplumber + PyMuPDF

## LiteLLM Security Policy

- Locked safe version: `litellm==1.82.6`
- Blocked compromised versions: `1.82.7`, `1.82.8`
- Do not use open-ended or floating LiteLLM version ranges in this phase.

## Non-Negotiable Design Rules

- The LLM never directly calls external APIs, FastAPI endpoints, or ChromaDB. Python handles all I/O.
- Billing answers must be strictly grounded in retrieved or selected bill context. If the answer is not in context, the system must say so.
- AC control uses a two-step intent path: classify intent first, then call the tool or endpoint.
- Billing uses structured bill parsing before answer generation.
- Each bill is one primary canonical record.
- `current_payable`, `total_payable_rounded`, and `payable_by_due_date` are distinct fields and must never be merged.

## Billing RAG Architecture

- The billing system uses a schema-first hybrid design.
- Direct structured lookup is the default path for exact billing questions.
- ChromaDB is a fallback and evidence layer, not the primary truth source.
- The three Chroma collections are:
  - `bill_fields`
  - `bill_charges`
  - `bill_history`

## Current Billing Status

- Billing slice lives in `src/aegis/billing/` (unified under the `aegis` package).
- Embedding, retrieval, and LLM formatting live inside `src/aegis/billing/rag/` and `src/aegis/billing/llm_formatter.py`.
- The current implementation uses:
  - rule-based query classification
  - canonical bill parsing from `pdfplumber` + `PyMuPDF` output
  - exact structured lookup as the primary working answer path
  - local canonical JSON persistence (`store_dir/canonical/`) plus Chroma upsert (`store_dir/chroma/`) via `BillingConfig`
  - CLI exposed through `uv run aegis-billing ...`
- Verified real sample-bill support currently includes:
  - `bill_id`, `account_no`, `bill_month`, `bill_date`, `due_date`, `disconnection_date`
  - `amounts.current_payable`, `amounts.total_payable_rounded`, `amounts.payable_by_due_date`
  - `amounts.last_payment_amount`, `amounts.last_payment_date`, `amounts.last_receipt_no`, `amounts.arrears_total`
  - selected `charges.*`, selected `consumption.*`, `history[]`, expanded `evidence_map`
- Verified real query currently works for:
  - "When was my last electricity bill paid, and what was the amount?"

## Query Routing Rules

- Exact-field questions go to structured lookup first.
- Charge and history questions use structured lookup first, with optional evidence retrieval.
- Unmapped or ambiguous billing questions use metadata-filtered semantic retrieval.
- Vector retrieval never overrides a valid exact structured value.

## Canonical Bill Fields

The canonical bill object must include:

- `source_doc_id`
- `bill_id`
- `account_no`
- `bill_month`
- `bill_date`
- `due_date`
- `disconnection_date`
- `amounts.current_payable`
- `amounts.total_payable_rounded`
- `amounts.payable_by_due_date`
- `amounts.last_payment_amount`
- `amounts.last_payment_date`
- `amounts.last_receipt_no`
- `amounts.arrears_total`
- `charges.*`
- `consumption.*`
- `history[]`
- `raw_text`
- `evidence_map`

## Source of Truth Priority

1. `ARCHITECTURE_LOCK.md`
2. `PROJECT_CONTEXT_HANDOFF.md`
3. `Claude.md`
4. XML prompt and task files only where non-conflicting

## Explicit Overrides

The chosen architecture is not:

- Ollama as the primary LLM runtime
- a LangChain-first orchestration design
- generic chunked RAG over bill text as the main billing strategy

The chosen architecture is:

- Gemini 2.5 Flash via LiteLLM
- schema-first billing QA with structured lookup first
- ChromaDB as fallback and evidence retrieval support

## Current Gaps

- Multi-bill ranking and selection is intentionally out of scope; billing query flow is locked to explicit single-bill context.

## Current Implementation Status

All three features implemented and tested (88 tests passing). Single unified `aegis` package.

---

## Production RAG Phase (APPROVED - 2026-03-29)

### Production RAG Goals
- Handle 10,000+ page PDF documents efficiently
- Implement hybrid search (BM25 + Vector) with RRF fusion
- Add Redis caching layer (50%+ API cost reduction)
- Add S3-compatible file storage for documents
- Add Celery for async task processing
- Add rate limiting for production deployment
- Add agentic features (query rewriting, document grading)
- Add Langfuse observability
- Design for cloud deployment readiness (AWS-compatible)

### Production Stack Decisions

| Component | Choice | Rationale |
|-----------|--------|-----------|
| **Hybrid Search** | OpenSearch | BM25 + Vector built-in, RRF fusion |
| **Metadata Storage** | PostgreSQL | Production standard |
| **Vector Storage** | pgvector | Inside PostgreSQL, cost-effective |
| **Caching** | Redis | 50%+ API cost reduction |
| **Async Tasks** | Celery + Redis | PDF processing, embeddings |
| **File Storage** | S3-compatible | Cloud-ready design |
| **Docker** | Yes | Full production setup |
| **Agentic Features** | Yes | Query rewriting + document grading |
| **Observability** | Langfuse | Full tracing |

### Cloud Deployment Readiness (AWS)

| Current (Local) | AWS Cloud (Future) |
|-----------------|-------------------|
| Docker Compose | ECS / EKS |
| Local PostgreSQL | RDS PostgreSQL |
| Local Redis | ElastiCache Redis |
| Local OpenSearch | OpenSearch Service |
| Local File Storage | S3 |
| Celery + Redis | SQS + Lambda |

### Reference Implementation
- [production-agentic-rag-course](https://github.com/jamwithai/production-agentic-rag-course) - 5.3K stars

### V1 Package Structure

```
src/aegis/
├── core/              config.py, orchestrator.py
├── billing/           answerer, cli, config, llm_formatter, query_classifier, types
│   ├── parser/        extractors, normalize, pvvnl_parser, msedcl_parser
│   └── rag/           embeddings, retriever, store
├── weather/           advisor, fetcher
├── ac_control/        classifier, client, server
└── ui/                streamlit_app
```

### Feature locations
- Billing RAG: `src/aegis/billing/` — complete
- Weather Advisor: `src/aegis/weather/` — OpenWeatherMap + mock fallback + LiteLLM recommendation
- AC Control: `src/aegis/ac_control/` — FastAPI mock server (port 8765) + LiteLLM intent classifier + httpx client
- Core: `src/aegis/core/config.py` (AegisConfig) + `src/aegis/core/orchestrator.py` (keyword routing + CLI)
- Streamlit: `src/aegis/ui/streamlit_app.py` — three-tab UI (prototype/testing surface only)

### Entry points
- `aegis` → orchestrator CLI (`aegis.core.orchestrator:main_cli`)
- `aegis-billing` → billing CLI (inspect/ingest/query)
- `aegis-ac-server` → AC mock hardware (port 8765)
- `aegis-ui` → Streamlit prototype UI

## Remaining Production Phase Items (require explicit user approval)

**LiteLLM becomes mandatory**
- `litellm_enabled` defaults to `True` across all configs
- Startup must validate LLM API key presence and fail clearly if missing
- Deterministic fallbacks remain as silent safety nets only

**Proper frontend**
- Streamlit is prototype-only; production gets a proper frontend
- Frontend calls FastAPI only — no direct Python imports

## Non-Negotiable Structural Rules

- Weather, AC, Billing remain fully independent — zero cross-feature coupling
- Secrets always in `.env`; never in yaml config files
- AC mock server on port 8765
